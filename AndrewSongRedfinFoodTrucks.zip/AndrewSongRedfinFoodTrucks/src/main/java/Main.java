import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SocrataService socrataService = new SocrataService();
        try {
            List<FoodTruckDto> foodTruckDtos = socrataService.getCurrentFoodTruckInfo();
            Scanner scanner = new Scanner(System.in);

            // Header
            System.out.println("NAME \t\t\t ADDRESS");

            for (int i = 0; i < foodTruckDtos.size(); i++) {
                System.out.printf("%s  %s %n",
                        foodTruckDtos.get(i).getApplicant(),
                        foodTruckDtos.get(i).getLocation());

                // Wait for user input every 10 results.
                if ((i+1) % 10 == 0) {
                    System.out.println("Press ENTER to see more results...");
                    scanner.nextLine();
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
