import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Class to call Socrata's rest apis and handle data.
 */
public class SocrataService {

    /**
     * Orchestrates GET api and filters out trucks not currently open.
     * @return - List<FoodTruckDto> - Trucks currently open.
     * @throws Exception when there is any kind of error. Message contains user friendly response.
     */

    public List<FoodTruckDto> getCurrentFoodTruckInfo() throws Exception {
        try {
            StringBuilder apiResult = new StringBuilder();
            URL url = new URL(buildQueryUrl());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line; 
            while ((line = rd.readLine()) != null) {
                apiResult.append(line);
            }
            rd.close();

            ObjectMapper mapper = new ObjectMapper();
            mapper.findAndRegisterModules();
            FoodTruckDto[] dtoArray = mapper.readValue(apiResult.toString(), FoodTruckDto[].class);
            List<FoodTruckDto> foodTruckDtos = Arrays.asList(dtoArray);
            return filterFoodTrucksByCurrentDate(foodTruckDtos);
        } catch (Exception e) {
            // log error
            throw new Exception("There was en error processing your request. Please try again later.");
        }
    }

    /**
     * Gets current day of week in String form.
     * @return - String - Current day of week. Ex - 'Monday' or 'Thursday'
     */
    private String getCurrentDay() {
        LocalDate date = LocalDate.now();
        DayOfWeek day = date.getDayOfWeek();
        return day.getDisplayName(TextStyle.FULL, Locale.US);
    }

    /**
     * Filters out list of truck dtos that are not open at current time.
     * @param foodTruckList - Input list wanting to be filtered.
     * @return - List<FoodTruckDto> - Filtered list.
     */
    private List<FoodTruckDto> filterFoodTrucksByCurrentDate(List<FoodTruckDto> foodTruckList) throws Exception {
        LocalTime now = LocalTime.now();
        List<FoodTruckDto> result = new ArrayList<>();
        try {
            result = foodTruckList.stream()
                    .filter(dto -> LocalTime.parse(dto.getStart24()).isBefore(now)
                            && hourIsAfter(dto.getEnd24(), now))
                    .collect(Collectors.toList());
        } catch (DateTimeParseException e) {
            throw new Exception("Unhandled case");
        }
        return result;
    }

    /**
     * Extracted function to reduce code complexity.
     * Determines if time is "24:00" and sets it accordingly to 0.
     * Since LocalTime datatype only accepts 0-23.
     * Have only seen 'end24' being potentially '24:00'.
     * @param left - String that is potentially 24.
     * @param right - Time wanting to be compared to.
     * @return - boolean - true or false.
     */
    private boolean hourIsAfter(String left, LocalTime right)  {
        try {
            return LocalTime.parse(left).isAfter(right);
        } catch (DateTimeParseException e) {
            if (left.equals("24:00")) {
                return LocalTime.parse("00:00").isAfter(right);
            }
            // log unhandled edge case.
            return false;
        }
    }

    /**
     * Constructs url.
     * @return - String - Constructed url.
     *          Contains param to filter on today and orders by applicant name.
     */
    private String buildQueryUrl() {
        String url = Constants.SF_GOV_HOST + Constants.GET_FOOD_TRUCK_INFO;
        url += String.format(Constants.PARAM_ORDER, "applicant");
        url += String.format("&" + Constants.PARAM_DAYOFWEEKSTR, getCurrentDay());
        return url;
    }
}
