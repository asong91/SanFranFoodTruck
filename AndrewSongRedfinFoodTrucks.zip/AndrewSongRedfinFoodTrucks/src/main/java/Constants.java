/**
 * File to house constants throughout project.
 * Can be refactored / split out once scope of project increases.
 */
public class Constants {

    public static String SF_GOV_HOST = "http://data.sfgov.org/";

    public static String GET_FOOD_TRUCK_INFO = "resource/bbb8-hzi6.json?";

    // API URL PARAMS
    public static String PARAM_ORDER = "$order=%s";
    public static String PARAM_DAYOFWEEKSTR = "dayofweekstr=%s";
}
