import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * POJO representing DTO received from Socrata's GET API
 * More fields exist in the response, but POJO contains the only ones in use in the code.
 * Feel free to add more as requirements change.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FoodTruckDto {

    private String applicant;
    private String location;
    private String starttime;
    private String endtime;
    private String start24;
    private String end24;

    /**
     * Default constructor.
     */
    public FoodTruckDto() {
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStart24() {
        return start24;
    }

    public void setStart24(String start24) {
        this.start24 = start24;
    }

    public String getEnd24() {
        return end24;
    }

    public void setEnd24(String end24) {
        this.end24 = end24;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }
}
