# Food Truck Finder
Proof-of-Concept command line application to find currently open food trucks in the San Francisco area. <br>
Uses Socrata API as a datasource.

**Note:** <br>
The given Socrata API did not return any noticeable field regarding a restaurant name so the `applicant` field was used as a substitute as it most closely correlated with a somewhat distinctive name.

## Building, Compiling and Running
<em>Requires Maven and Java 8 or higher</em> <br> <br>
Dependencies are managed via Maven. <br>
To install dependencies, first cd in parent folder (AndrewSongRedfinFoodTrucks) folder and run: <br>
`mvn clean install`

To compile, run: <br>
`mvn compile`

Once dependencies are installed and code is compiled, run by using the following command: <br>
`mvn exec:java -Dexec.mainClass=Main`
